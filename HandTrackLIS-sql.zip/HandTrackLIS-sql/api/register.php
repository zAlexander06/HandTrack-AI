<?php
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Metodo non consentito.'], 405);
}

$body     = getJsonBody();
$realname = trim($body['realname']  ?? '');
$surname  = trim($body['surname']   ?? '');
$username = trim($body['username']  ?? '');
$email    = trim($body['email']     ?? '');
$password = trim($body['password']  ?? '');   // <-- plain text, non più pre-hashata

if (!$realname || !$surname || !$username || !$email || !$password) {
    jsonResponse(['error' => 'Tutti i campi sono obbligatori.'], 400);
}

// ── Validazione password ──────────────────────────────────────────
$pwErrors = [];
if (strlen($password) < 8)                          $pwErrors[] = 'almeno 8 caratteri';
if (!preg_match('/[A-Z]/', $password))               $pwErrors[] = 'almeno una lettera maiuscola';
if (!preg_match('/[a-z]/', $password))               $pwErrors[] = 'almeno una lettera minuscola';
if (!preg_match('/[0-9]/', $password))               $pwErrors[] = 'almeno un numero';
if (!preg_match('/[\W_]/', $password))               $pwErrors[] = 'almeno un carattere speciale';

if ($pwErrors) {
    jsonResponse(['error' => 'Password non valida: ' . implode(', ', $pwErrors) . '.'], 422);
}

$hash = password_hash($password, PASSWORD_BCRYPT);
// ─────────────────────────────────────────────────────────────────

$db = getDB();

try {
    $stmt = $db->prepare(
        'INSERT INTO users (realName, surname, username, email, password_hash)
         VALUES (:realname, :surname, :username, :email, :hash)'
    );
    $stmt->execute([
        ':realname' => $realname,
        ':surname'  => $surname,
        ':username' => $username,
        ':email'    => $email,
        ':hash'     => $hash,
    ]);

    $newId = (int)$db->lastInsertId();
    jsonResponse(['id' => $newId, 'username' => $username, 'email' => $email]);

} catch (PDOException $e) {
    if ($e->getCode() === '23000') {
        $msg = $e->getMessage();
        if (stripos($msg, 'username') !== false) jsonResponse(['error' => 'Username già in uso.'], 409);
        if (stripos($msg, 'email')    !== false) jsonResponse(['error' => 'Email già registrata.'], 409);
        if (stripos($msg, 'realName') !== false) jsonResponse(['error' => 'Nome già in uso.'], 409);
        jsonResponse(['error' => 'Username o email già in uso.'], 409);
    }
    jsonResponse(['error' => 'Errore durante la registrazione: ' . $e->getMessage()], 500);
}