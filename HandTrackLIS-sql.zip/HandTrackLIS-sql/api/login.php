<?php
// ================================================================
// api/login.php — Autenticazione utente
// POST { email, password }
// ================================================================
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Metodo non consentito.'], 405);
}

$body     = getJsonBody();
$email    = trim($body['email']    ?? '');
$password = trim($body['password'] ?? '');

if (!$email || !$password) {
    jsonResponse(['error' => 'Email e password sono obbligatorie.'], 400);
}

$db = getDB();

$stmt = $db->prepare(
    'SELECT id, username, email, realName, surname, role_user, password_hash
     FROM users
     WHERE email = :email
     LIMIT 1'
);
$stmt->execute([':email' => $email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    jsonResponse(['error' => 'Email o password errati.'], 401);
}

$db->prepare('UPDATE users SET status_user = "online" WHERE id = :id')
   ->execute([':id' => $user['id']]);

jsonResponse([
    'id'       => (int)$user['id'],
    'username' => $user['username'],
    'email'    => $user['email'],
    'realname' => $user['realName'],
    'surname'  => $user['surname'],
    'role'     => $user['role_user'],
]);